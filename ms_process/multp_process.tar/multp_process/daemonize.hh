#ifndef DAEMON_HH
#define DAEMON_HH

int daemon( int nochdir, int noclose );

#endif
